-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 05, 2022 at 06:31 AM
-- Server version: 8.0.28
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clinical_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `Appointment_ID` int NOT NULL,
  `Appointment_Type` varchar(45) NOT NULL,
  `Date_Created` date NOT NULL,
  `Appointment_Date` date NOT NULL,
  `Appointment_Time` varchar(45) NOT NULL,
  `Patient_ID` varchar(255) NOT NULL,
  `Doctor_ID` int NOT NULL,
  `Department` varchar(250) NOT NULL,
  `Problem` text NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`Appointment_ID`, `Appointment_Type`, `Date_Created`, `Appointment_Date`, `Appointment_Time`, `Patient_ID`, `Doctor_ID`, `Department`, `Problem`, `Status`) VALUES
(4, 'Pre-Bookable Appointments', '2022-06-20', '2022-06-24', '10AM-11AM', 'Fait_91109_62aabd5ba9a16', 1, 'Neuro', '  Need to see a doctor for neuro checkup', 'Pending'),
(6, 'Pre-Bookable Appointments', '2022-06-28', '2022-06-25', '10AM-11AM', 'Fait_91109_62aabd5ba9a16', 1, 'Neuro', ' Body pains and dizziness', 'Completed'),
(7, 'Pre-Bookable Appointments', '2022-06-28', '2022-07-09', '12PM-01PM', 'Saku_46744_62bab1bff192d', 1, 'Radiology', 'Chest X-ray examination', 'Registered'),
(8, 'Pre-Bookable Appointments', '2022-06-28', '2022-06-24', '10AM-11AM', 'Fait_91109_62aabd5ba9a16', 1, 'Neuro', ' General neuro examinations', 'Pending'),
(9, 'Telephone Consultations', '2022-06-29', '2022-07-09', '2PM-3PM', 'Love_33215_62bab17e23620', 3, 'Orthopaedic', ' High fever and dizziness', 'Registered'),
(10, 'Telephone Consultations', '2022-06-29', '2022-08-06', '4PM-5PM', 'Samu_26774_62aab77f4d498', 6, 'Orthopaedic', '  High fever and dizziness', 'Registered'),
(11, 'Pre-Bookable Appointments', '2022-06-29', '2022-06-17', '10AM-11AM', 'Aida_81736_62bbb4e043b44', 5, 'Neuro', '   High fever', 'Canceled'),
(12, 'Routine checkup', '2022-06-30', '2022-07-08', '2PM-3PM', 'Saku_52478259_62aa90d61ecfd', 6, 'General', ' General healthcare checkup', 'Registered'),
(13, 'Pre-Bookable Appointments', '2022-06-30', '2022-07-07', '10AM-11AM', 'Saku_52478259_62aa90d61ecfd', 2, 'Orthopaedic', 'Bone aching and joint swelling', 'Registered'),
(14, 'Pre-Bookable Appointments', '2022-07-18', '2022-07-30', '2PM-3PM', 'Aida_81736_62bbb4e043b44', 5, 'Orthopaedic', ' Kneel injury', 'Registered');

--
-- Triggers `appointment`
--
DELIMITER $$
CREATE TRIGGER `after_appointment_insert` AFTER INSERT ON `appointment` FOR EACH ROW BEGIN
   
      INSERT INTO system_notifications(Action, Date_Created)
      VALUES('Appointment registerd',NOW());
   
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `building_block`
--

CREATE TABLE `building_block` (
  `B_ID` int NOT NULL,
  `Block_Floor` varchar(45) NOT NULL,
  `Block_Code` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `building_block`
--

INSERT INTO `building_block` (`B_ID`, `Block_Floor`, `Block_Code`) VALUES
(6, 'Block 2', 'B002'),
(7, 'Block 1', 'B001'),
(8, 'Block 13', 'B013'),
(9, 'Block 20', 'B020');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `Dept_ID` int NOT NULL,
  `Dept_Name` varchar(45) NOT NULL,
  `HOD` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`Dept_ID`, `Dept_Name`, `HOD`) VALUES
(2, '', 'Prof Degushi'),
(3, '', 'Prof Ani'),
(8, '', 'Prof. Joe'),
(9, '', 'Prof. Joe');

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `Doctor_ID` int NOT NULL,
  `First_Name` varchar(100) NOT NULL,
  `Last_Name` varchar(100) NOT NULL,
  `DOB` date DEFAULT NULL,
  `Gender` varchar(10) DEFAULT NULL,
  `Email` varchar(45) NOT NULL,
  `Department` varchar(45) NOT NULL,
  `Phone` varchar(45) DEFAULT NULL,
  `City` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Details` text NOT NULL,
  `Profile_Image` varchar(255) NOT NULL,
  `Status` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`Doctor_ID`, `First_Name`, `Last_Name`, `DOB`, `Gender`, `Email`, `Department`, `Phone`, `City`, `Details`, `Profile_Image`, `Status`) VALUES
(1, 'Daniel', 'Robert', '1991-06-05', 'Male', 'danielrobert@rlg.com', 'Optometrics', '+44207373773', 'Jarkata Indonesia', 'Doctor Brown has been a medical doctor for 6 years. He has won many awards in optometrics', 'bf72d4aadf8c68a5a78495af0b024257.jpg', 'On Vacation'),
(2, 'Sonia', 'Hills', '1997-10-24', 'Female', 'soniahills@rlg.com', 'Orthapaedic', '+18807373773', 'New York America', 'Sonia Hills is a renowned medical doctor who has practised for 4 years. she has won many awards in orthopaedics', '94d23f801a5e78291aa01be21ffb7890.jpg', 'Available'),
(3, 'Nestor', 'Ugwu', '1990-03-15', 'Male', 'nestor@divine-clinic.com', 'General Medicine', '+1896453245', 'California', 'Nestor is a renowned medical doctor who has practised medicine for 5 years. He is specialised in general medicine and anatomy', '740c8e212db58a53fc2ac4bfd07e00b6.jfif', 'On Leave'),
(5, 'Moses', 'Kings', '1989-06-10', 'Male', 'moseskings@rlg.com', 'General Medicine', '+2349574302395', 'Lagos Nigeria', 'Moses has been working with RLG Clinics for the past 7 years. He has won many awards in general medicine and optometrists.', 'dfd278aa410762aebbddfcf037750bc7.jpg', 'Available'),
(6, 'MacJoe', 'Nkurumah', '1988-06-06', 'Male', 'macjoe@rlg.com', 'Orthapaedic', '+2339590876', 'Accra Ghana', 'MacJoe has been working with RLG Clinics for the past 8 years. He has won many awards in general medicine and orthopaedics.', '08620a5dc2430f0ef36e4cca157b7210.jpg', 'Available'),
(7, 'Kwame', 'Mandela', '1993-06-08', 'Male', 'kwame123@rlg.com', 'Gynacology', '+2327860965', 'South Africa', 'Kwame has been working with RLG Clinics for the past 7 years. He has won many awards in Gynaecology and optometrists.', '419bb168045c88c2994fa273d38d78a1.jpg', 'Pending'),
(8, 'Sara', 'Degushi', '1987-06-17', 'Male', 'sarapurity@rlg.com', 'Optometrics', '+81783663893', 'Tokyo Japan', 'Sara has been working with RLG Clinics for the past 10 years. She has won many awards in Gynaecology and optometrists.', 'e5489f281ee024a3a8f7851f57d58e34.jpg', 'On Vacation');

--
-- Triggers `doctor`
--
DELIMITER $$
CREATE TRIGGER `after_doctor_insert` AFTER INSERT ON `doctor` FOR EACH ROW BEGIN
   
      INSERT INTO system_notifications(Action, Date_Created)
      VALUES('New doctor added',NOW());
   
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE `employees` (
  `Employee_ID` int NOT NULL,
  `Emp_First_Name` varchar(45) DEFAULT NULL,
  `Emp_Last_Name` varchar(45) DEFAULT NULL,
  `Emp_Gender` varchar(45) DEFAULT NULL,
  `Emp_DOB` date DEFAULT NULL,
  `Emp_Email` varchar(45) DEFAULT NULL,
  `Emp_Phone` varchar(45) DEFAULT NULL,
  `Dept_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `employee_manager`
--

CREATE TABLE `employee_manager` (
  `Emp_ID` int NOT NULL,
  `First_Name` varchar(45) NOT NULL,
  `Last_Name` varchar(45) NOT NULL,
  `Gender` varchar(45) DEFAULT NULL,
  `DOB` date DEFAULT NULL,
  `Address` varchar(150) DEFAULT NULL,
  `Email` varchar(45) NOT NULL,
  `Phone` varchar(45) DEFAULT NULL,
  `Dept_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `has_insurance`
--

CREATE TABLE `has_insurance` (
  `Insurance_Code` varchar(100) NOT NULL,
  `Insurance_Company` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `Insurance_Plan` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Medical_Coverage` text CHARACTER SET utf8 COLLATE utf8_general_ci,
  `Insurance_Fee` float DEFAULT NULL,
  `Co_Pay_Insurance` float DEFAULT NULL,
  `Co_Insurance` text CHARACTER SET utf8 COLLATE utf8_general_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `has_insurance`
--

INSERT INTO `has_insurance` (`Insurance_Code`, `Insurance_Company`, `Insurance_Plan`, `Medical_Coverage`, `Insurance_Fee`, `Co_Pay_Insurance`, `Co_Insurance`) VALUES
('NHIS_18978_62ad0600ba480', 'AXA Direct Life Insurance Co., Ltd.', 'Social Insurance', 'Essential health benefits', 250000, 12000, 'NN Life Insurance Company., Ltd.'),
('NHIS_37311_62ad05bae294b', 'Mitsui Sumitomo Aioi Life Insurance Co., Ltd', 'Social Insurance', 'Essential health benefits', 250000, 12000, 'NN Life Insurance Company., Ltd.'),
('NHIS_44766_62ad061d66e53', 'AXA Life Insurance Co., Ltd.', 'Social Insurance', 'Essential health benefits', 280000, 14000, 'NN Life Insurance Company., Ltd.'),
('NHIS_77325_62ad058bdff39', 'Fukokushinrai Life Insurance Co.,Ltd.', 'Social Insurance', 'Essential health benefits', 150000, 8000, 'SBI Life Insurance Co., Ltd.'),
('NHS1001', 'AEON Allianz Life Insurance Co., Ltd', 'social insurance', 'Essential benefits', 90000, 2000, 'Nippon Insurance ltd');

-- --------------------------------------------------------

--
-- Table structure for table `health_insurance`
--

CREATE TABLE `health_insurance` (
  `Insurance_Number` varchar(150) NOT NULL,
  `Creation_Date` date DEFAULT NULL,
  `Expiry_Date` date DEFAULT NULL,
  `Insurance_Type` varchar(200) NOT NULL,
  `Insurance_Code` varchar(100) NOT NULL,
  `Patient_ID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `health_insurance`
--

INSERT INTO `health_insurance` (`Insurance_Number`, `Creation_Date`, `Expiry_Date`, `Insurance_Type`, `Insurance_Code`, `Patient_ID`) VALUES
('NHIS0010090', '2022-06-25', '2022-06-29', 'Social Insurance (SI)', 'NHIS_44766_62ad061d66e53', 'Sofi_67376_62aabe2d48201'),
('NHIS0010098', '2022-03-17', '2022-08-20', 'National Health Insurance (NHI)', 'NHS1001', 'Samu_26774_62aab77f4d498'),
('NHIS00234', '2021-07-08', '2022-11-17', 'Social Insurance (SI)', 'NHIS_77325_62ad058bdff39', 'Saku_52478259_62aa90d61ecfd');

--
-- Triggers `health_insurance`
--
DELIMITER $$
CREATE TRIGGER `after_insurance_insert` AFTER INSERT ON `health_insurance` FOR EACH ROW BEGIN
    
     INSERT INTO system_notifications(Action, Date_Created)
     VALUES('New Insurance recorded added',NOW());
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `hospital_bills`
--

CREATE TABLE `hospital_bills` (
  `Bill_ID` int NOT NULL,
  `Doctor_charges` float DEFAULT '0',
  `Medicine_Charge` float DEFAULT '0',
  `Room_Charge` float DEFAULT '0',
  `Lab_Charge` float DEFAULT '0',
  `Nurse_Charge` float DEFAULT '0',
  `Radiology_Charges` float DEFAULT '0',
  `Miscelleneous_Charges` float DEFAULT '0',
  `Patient_ID` varchar(255) NOT NULL,
  `Insurance_Number` varchar(150) NOT NULL,
  `Bill_Status` varchar(45) NOT NULL DEFAULT 'UNPAID',
  `Bill_Date` date NOT NULL,
  `Bill_Discount` float NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `hospital_bills`
--

INSERT INTO `hospital_bills` (`Bill_ID`, `Doctor_charges`, `Medicine_Charge`, `Room_Charge`, `Lab_Charge`, `Nurse_Charge`, `Radiology_Charges`, `Miscelleneous_Charges`, `Patient_ID`, `Insurance_Number`, `Bill_Status`, `Bill_Date`, `Bill_Discount`) VALUES
(1, 20000, 5000, 15000, 1500, 2500, 1000, 0, 'Saku_52478259_62aa90d61ecfd', 'NHIS00234', 'UNPAID', '2022-05-20', 0),
(2, 50000, 20000, 0, 9000, 0, 0, 1000, 'Saku_52478259_62aa90d61ecfd', 'NHIS00234', 'PAID', '2022-06-26', 10),
(3, 80000, 24000, 40000, 10000, 0, 0, 3000, 'Saku_52478259_62aa90d61ecfd', 'NHIS00234', 'PAID', '2022-06-22', 15),
(4, 45000, 18000, 22000, 0, 0, 7000, 3200, 'Saku_52478259_62aa90d61ecfd', 'NHIS00234', 'UNPAID', '2022-06-22', 12);

--
-- Triggers `hospital_bills`
--
DELIMITER $$
CREATE TRIGGER `after_bill_insert` AFTER INSERT ON `hospital_bills` FOR EACH ROW BEGIN
   
      INSERT INTO system_notifications(Action, Date_Created)
      VALUES('New hospital bill added',NOW());
   
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `ID` int NOT NULL,
  `Email` varchar(200) NOT NULL,
  `User_Name` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`ID`, `Email`, `User_Name`, `password`) VALUES
(1, 'admin@rlg.com', 'George', '$2y$10$theverylongvaluesiuseOX9QnccaTyeBclIFgw7DkoVb6yrKxUb.'),
(2, 'admin@admin.com', 'admin2', '$2y$10$theverylongvaluesiuseOX9QnccaTyeBclIFgw7DkoVb6yrKxUb.');

-- --------------------------------------------------------

--
-- Table structure for table `medical_lab`
--

CREATE TABLE `medical_lab` (
  `Lab_ID` int NOT NULL,
  `Lab_Test_Type` varchar(45) NOT NULL,
  `Category` varchar(45) NOT NULL,
  `Temprature` float DEFAULT NULL,
  `Blood_Presure` float DEFAULT NULL,
  `Blood_Group` varchar(45) DEFAULT NULL,
  `Genotype` varchar(45) DEFAULT NULL,
  `Weight` float DEFAULT NULL,
  `Height` float DEFAULT NULL,
  `Test_Date` date NOT NULL,
  `Patient_ID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Triggers `medical_lab`
--
DELIMITER $$
CREATE TRIGGER `after_lab_insert` AFTER INSERT ON `medical_lab` FOR EACH ROW BEGIN
   
      INSERT INTO system_notifications(Action, Date_Created)
      VALUES('New lab result added',NOW());
   
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE `medicine` (
  `Medicine_ID` int NOT NULL,
  `Medicine_Name` varchar(45) NOT NULL,
  `Medicine_Type` varchar(45) DEFAULT NULL,
  `Medicine_Price` float DEFAULT NULL,
  `Description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`Medicine_ID`, `Medicine_Name`, `Medicine_Type`, `Medicine_Price`, `Description`) VALUES
(1, 'Terry Naturally, AnxioCalm', 'Anxiety And Depression', 50000, 'For anxiety and depression'),
(2, 'Herbal Sleep 30 Caps', 'Insomnia', 2000, 'Drug for Insomnia'),
(3, 'Amphetamine', 'Stimulant', 1000, 'one of the most frequently prescribed stimulants as of 2022');

-- --------------------------------------------------------

--
-- Table structure for table `medicine_prescription`
--

CREATE TABLE `medicine_prescription` (
  `Prescription_ID` int NOT NULL,
  `Medicine_ID` int NOT NULL,
  `Record_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `medicine_record`
--

CREATE TABLE `medicine_record` (
  `Med_Record_ID` int NOT NULL,
  `Quantity` int DEFAULT NULL,
  `Supplied_Date` date DEFAULT NULL,
  `Manufactured_Date` date DEFAULT NULL,
  `Expiry_Date` date NOT NULL,
  `Company_Name` varchar(45) DEFAULT NULL,
  `Medicine_ID` int NOT NULL,
  `Company_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Triggers `medicine_record`
--
DELIMITER $$
CREATE TRIGGER `after_med_record_insert` AFTER INSERT ON `medicine_record` FOR EACH ROW BEGIN
   
      INSERT INTO system_notifications(Action, Date_Created)
      VALUES('New medicine record added',NOW());
   
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `Patient_ID` varchar(255) NOT NULL,
  `Patient_First_Name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Patient_Last_Name` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Patient_Email` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `Patient_Gender` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Patient_Citizenship` varchar(100) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Patient_City` varchar(200) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `Patient_DOB` date NOT NULL,
  `Patient_Phone` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`Patient_ID`, `Patient_First_Name`, `Patient_Last_Name`, `Patient_Email`, `Patient_Gender`, `Patient_Citizenship`, `Patient_City`, `Patient_DOB`, `Patient_Phone`) VALUES
('Aida_81736_62bbb4e043b44', 'Aidan', 'John', 'aidanjohn@rlg.com', 'Male', 'Japanese', 'Osaka', '1995-02-16', '+81200202483'),
('Fait_91109_62aabd5ba9a16', 'Faith', 'Moore', 'faithmoore@gmail.com', 'Female', 'Nigerian', 'Abuja, Nigeria', '2002-02-09', '+2349087654'),
('Iida_35172_62bab14cae4ab', 'Iida', 'Kuta', 'iida-kuta@gmail.com', 'Male', 'Japanese', 'Kyoto', '2007-02-23', '+8190876543'),
('LIZ_1001_62aa8fd757844', 'LIZ', 'Hanky', 'liz@rlg.com', 'Female', 'Japanese', 'Toyonaka-shi', '2022-02-04', '0828209435'),
('Love_33215_62bab17e23620', 'Loveth', 'Frank', 'loveth@gmail.com', 'Female', 'Japanese', 'Tokyo', '2001-01-13', '+8190876543'),
('Saku_46744_62bab1bff192d', 'Sakura', 'Ryotoro', 'sakura@gmail.com', 'Female', 'Japanese', 'Hiroshima', '1999-10-28', '+8190876578'),
('Saku_52478259_62aa90d61ecfd', 'Sakura', 'Misao', 'sakuramisao@rlg.com', 'Female', 'Japanese', 'Osaka City', '1996-02-16', '090862552563'),
('Samu_26774_62aab77f4d498', 'Samuel', 'Perevibes', 'peresam@ams.com', 'Male', 'American', 'New York City', '1999-06-08', '+1876548234'),
('Sofi_67376_62aabe2d48201', 'Sofia', 'Boolean', 'solphbool@uk.co.ac', 'Male', 'British', 'United Kingdom', '1998-11-20', '+4467234589');

--
-- Triggers `patient`
--
DELIMITER $$
CREATE TRIGGER `after_patient_insert` AFTER INSERT ON `patient` FOR EACH ROW BEGIN
   
      INSERT INTO system_notifications(Action, Date_Created)
      VALUES('New patient added',NOW());
   
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `patient_admission`
--

CREATE TABLE `patient_admission` (
  `Admission_ID` int NOT NULL,
  `Admission_Date` date NOT NULL,
  `Discharge_Date` varchar(45) DEFAULT NULL,
  `Room_ID` int NOT NULL,
  `Patient_ID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `patient_admission`
--

INSERT INTO `patient_admission` (`Admission_ID`, `Admission_Date`, `Discharge_Date`, `Room_ID`, `Patient_ID`) VALUES
(2, '2022-06-06', '2022-06-22', 3, 'Samu_26774_62aab77f4d498'),
(3, '2022-06-16', '2022-06-30', 1, 'Sofi_67376_62aabe2d48201'),
(4, '2022-06-18', '2022-07-30', 1, 'Saku_52478259_62aa90d61ecfd'),
(5, '2022-06-02', '2022-06-25', 1, 'Fait_91109_62aabd5ba9a16'),
(7, '2022-07-01', '2022-07-09', 1, 'Aida_81736_62bbb4e043b44');

--
-- Triggers `patient_admission`
--
DELIMITER $$
CREATE TRIGGER `after_admission_insert` AFTER INSERT ON `patient_admission` FOR EACH ROW BEGIN
   
      INSERT INTO system_notifications(Action, Date_Created)
      VALUES('New patient admitted',NOW());
   
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `patient_record`
--

CREATE TABLE `patient_record` (
  `Record_ID` int NOT NULL,
  `Diagnoses` varchar(100) NOT NULL,
  `Description` varchar(150) DEFAULT NULL,
  `Patient_ID` varchar(255) NOT NULL,
  `Doctor_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `payment_ID` int NOT NULL,
  `Payment_Type` varchar(250) NOT NULL,
  `Payment_Status` varchar(45) NOT NULL,
  `Payment_Date` date NOT NULL,
  `Bill_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `payment`
--

INSERT INTO `payment` (`payment_ID`, `Payment_Type`, `Payment_Status`, `Payment_Date`, `Bill_ID`) VALUES
(1, 'Credit card', 'Completed', '2022-06-19', 2),
(2, 'Credit card', 'Completed', '2022-06-22', 3),
(3, 'Credit card', 'Canceled', '2022-06-22', 1);

-- --------------------------------------------------------

--
-- Table structure for table `radiology_test`
--

CREATE TABLE `radiology_test` (
  `Rad_ID` int NOT NULL,
  `Category` varchar(45) NOT NULL,
  `Scan_Image` varchar(255) DEFAULT NULL,
  `Scan_Date` date NOT NULL,
  `Patient_ID` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Triggers `radiology_test`
--
DELIMITER $$
CREATE TRIGGER `after_radiology_insert` AFTER INSERT ON `radiology_test` FOR EACH ROW BEGIN
   
      INSERT INTO system_notifications(Action, Date_Created)
      VALUES('Radiology result added',NOW());
   
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `room`
--

CREATE TABLE `room` (
  `Room_ID` int NOT NULL,
  `Room_No` varchar(45) NOT NULL,
  `Status` varchar(20) NOT NULL,
  `Block_B_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `room`
--

INSERT INTO `room` (`Room_ID`, `Room_No`, `Status`, `Block_B_ID`) VALUES
(1, 'Room 20', 'Available', 8),
(2, 'Room 10', 'Occupied', 9),
(3, 'Room 2', 'Available', 7),
(4, 'Room 10', 'Available', 7);

--
-- Triggers `room`
--
DELIMITER $$
CREATE TRIGGER `after_room_insert` AFTER INSERT ON `room` FOR EACH ROW BEGIN
   
      INSERT INTO system_notifications(Action, Date_Created)
      VALUES('New room added',NOW());
   
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `salary_record`
--

CREATE TABLE `salary_record` (
  `salary_ID` int NOT NULL,
  `Salary` float NOT NULL,
  `Bonus` float DEFAULT NULL,
  `Compesation` float DEFAULT NULL,
  `Bank_Name` varchar(45) DEFAULT NULL,
  `Bank_Acct` varchar(45) DEFAULT NULL,
  `Tax` float DEFAULT NULL,
  `Emp_ID` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `supplier_company`
--

CREATE TABLE `supplier_company` (
  `Company_ID` int NOT NULL,
  `Company_Name` varchar(100) NOT NULL,
  `Email` varchar(45) NOT NULL,
  `Phone` varchar(45) DEFAULT NULL,
  `Address` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

-- --------------------------------------------------------

--
-- Table structure for table `system_notifications`
--

CREATE TABLE `system_notifications` (
  `notification_ID` int NOT NULL,
  `Action` varchar(250) NOT NULL,
  `Date_Created` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Dumping data for table `system_notifications`
--

INSERT INTO `system_notifications` (`notification_ID`, `Action`, `Date_Created`) VALUES
(1, 'New Insurance recorded added', '2022-06-18'),
(2, 'New doctor added', '2022-06-18'),
(3, 'New doctor added', '2022-06-18'),
(4, 'Appointment registerd', '2022-06-18'),
(5, 'New patient admitted', '2022-06-18'),
(6, 'New patient admitted', '2022-06-18'),
(7, 'Appointment registerd', '2022-06-18'),
(8, 'Appointment registerd', '2022-06-20'),
(9, 'New hospital bill added', '2022-06-21'),
(10, 'New hospital bill added', '2022-06-21'),
(11, 'New hospital bill added', '2022-06-22'),
(12, 'New hospital bill added', '2022-06-22'),
(13, 'Appointment registerd', '2022-06-28'),
(14, 'New patient added', '2022-06-28'),
(15, 'New patient added', '2022-06-28'),
(16, 'New patient added', '2022-06-28'),
(17, 'New doctor added', '2022-06-28'),
(18, 'New doctor added', '2022-06-28'),
(19, 'New doctor added', '2022-06-28'),
(20, 'New doctor added', '2022-06-28'),
(21, 'Appointment registerd', '2022-06-28'),
(22, 'Appointment registerd', '2022-06-28'),
(23, 'Appointment registerd', '2022-06-28'),
(24, 'Appointment registerd', '2022-06-29'),
(25, 'Appointment registerd', '2022-06-29'),
(26, 'New patient added', '2022-06-29'),
(27, 'Appointment registerd', '2022-06-29'),
(28, 'New patient admitted', '2022-06-29'),
(29, 'Appointment registerd', '2022-06-30'),
(30, 'Appointment registerd', '2022-06-30'),
(31, 'New patient added', '2022-07-13'),
(32, 'New patient added', '2022-07-18'),
(33, 'Appointment registerd', '2022-07-18'),
(34, 'New patient added', '2022-07-26'),
(35, 'Appointment registerd', '2022-07-26'),
(36, 'New patient added', '2022-07-26');

-- --------------------------------------------------------

--
-- Table structure for table `system_users`
--

CREATE TABLE `system_users` (
  `User_ID` int NOT NULL,
  `First_Name` varchar(100) DEFAULT NULL,
  `Last_Name` varchar(100) DEFAULT NULL,
  `Password` varchar(200) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `User_Role` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`Appointment_ID`,`Patient_ID`,`Doctor_ID`),
  ADD UNIQUE KEY `Appointment_ID_UNIQUE` (`Appointment_ID`),
  ADD KEY `fk_Appointment_Patient_idx` (`Patient_ID`),
  ADD KEY `fk_Appointment_Doctor1_idx` (`Doctor_ID`),
  ADD KEY `appointment_dept` (`Department`),
  ADD KEY `appointment_type` (`Appointment_Type`),
  ADD KEY `appointment_status` (`Status`);

--
-- Indexes for table `building_block`
--
ALTER TABLE `building_block`
  ADD PRIMARY KEY (`B_ID`),
  ADD UNIQUE KEY `B_ID_UNIQUE` (`B_ID`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`Dept_ID`),
  ADD UNIQUE KEY `Dept_ID_UNIQUE` (`Dept_ID`),
  ADD KEY `deptname` (`Dept_Name`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`Doctor_ID`),
  ADD UNIQUE KEY `Doctor_ID_UNIQUE` (`Doctor_ID`),
  ADD KEY `doc_first_idx` (`First_Name`),
  ADD KEY `doc_last_idx` (`Last_Name`),
  ADD KEY `doc_email_idx` (`Email`),
  ADD KEY `doc_dept_idx` (`Department`),
  ADD KEY `profile_image_idx` (`Profile_Image`);

--
-- Indexes for table `employees`
--
ALTER TABLE `employees`
  ADD PRIMARY KEY (`Employee_ID`,`Dept_ID`),
  ADD UNIQUE KEY `Employee_ID_UNIQUE` (`Employee_ID`),
  ADD KEY `fk_Employee_Department1_idx` (`Dept_ID`);

--
-- Indexes for table `employee_manager`
--
ALTER TABLE `employee_manager`
  ADD PRIMARY KEY (`Emp_ID`,`Dept_ID`),
  ADD UNIQUE KEY `Emp_ID_UNIQUE` (`Emp_ID`),
  ADD KEY `fk_Employee_Manager_Department1_idx` (`Dept_ID`);

--
-- Indexes for table `has_insurance`
--
ALTER TABLE `has_insurance`
  ADD PRIMARY KEY (`Insurance_Code`),
  ADD UNIQUE KEY `Insurance_Code_UNIQUE` (`Insurance_Code`);

--
-- Indexes for table `health_insurance`
--
ALTER TABLE `health_insurance`
  ADD PRIMARY KEY (`Insurance_Number`,`Insurance_Code`,`Patient_ID`),
  ADD UNIQUE KEY `Insurance_Number_UNIQUE` (`Insurance_Number`),
  ADD KEY `fk_Health_Insurance_Has_Insurance1_idx` (`Insurance_Code`),
  ADD KEY `fk_Health_Insurance_Patient1_idx` (`Patient_ID`);

--
-- Indexes for table `hospital_bills`
--
ALTER TABLE `hospital_bills`
  ADD PRIMARY KEY (`Bill_ID`,`Patient_ID`,`Insurance_Number`),
  ADD UNIQUE KEY `Bill_ID_UNIQUE` (`Bill_ID`),
  ADD KEY `fk_Hospital_Bills_Patient1_idx` (`Patient_ID`),
  ADD KEY `fk_Hospital_Bills_Health_Insurance1_idx` (`Insurance_Number`),
  ADD KEY `bill_stat` (`Bill_Status`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `medical_lab`
--
ALTER TABLE `medical_lab`
  ADD PRIMARY KEY (`Lab_ID`,`Patient_ID`),
  ADD UNIQUE KEY `Lab_ID_UNIQUE` (`Lab_ID`),
  ADD KEY `fk_Medical_Lab_Patient1_idx` (`Patient_ID`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`Medicine_ID`),
  ADD UNIQUE KEY `Medicine_ID_UNIQUE` (`Medicine_ID`);

--
-- Indexes for table `medicine_prescription`
--
ALTER TABLE `medicine_prescription`
  ADD PRIMARY KEY (`Prescription_ID`,`Medicine_ID`,`Record_ID`),
  ADD KEY `fk_Medicine_Prescription_Medicine1_idx` (`Medicine_ID`),
  ADD KEY `fk_Medicine_Prescription_Patient_Record1_idx` (`Record_ID`);

--
-- Indexes for table `medicine_record`
--
ALTER TABLE `medicine_record`
  ADD PRIMARY KEY (`Med_Record_ID`,`Medicine_ID`,`Company_ID`),
  ADD UNIQUE KEY `Med_Record_ID_UNIQUE` (`Med_Record_ID`),
  ADD KEY `fk_Medicine_Record_Medicine1_idx` (`Medicine_ID`),
  ADD KEY `fk_Medicine_Record_Supplier_Company1_idx` (`Company_ID`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`Patient_ID`),
  ADD UNIQUE KEY `Patient_ID_UNIQUE` (`Patient_ID`),
  ADD KEY `pat_first_idx` (`Patient_First_Name`),
  ADD KEY `pat_last_idx` (`Patient_Last_Name`),
  ADD KEY `pat_email_idx` (`Patient_Email`);

--
-- Indexes for table `patient_admission`
--
ALTER TABLE `patient_admission`
  ADD PRIMARY KEY (`Admission_ID`,`Room_ID`,`Patient_ID`),
  ADD UNIQUE KEY `Admission_ID_UNIQUE` (`Admission_ID`),
  ADD KEY `fk_Patient_Admission_Room1_idx` (`Room_ID`),
  ADD KEY `fk_Patient_Admission_Patient1_idx` (`Patient_ID`);

--
-- Indexes for table `patient_record`
--
ALTER TABLE `patient_record`
  ADD PRIMARY KEY (`Record_ID`,`Patient_ID`,`Doctor_ID`),
  ADD UNIQUE KEY `Record_ID_UNIQUE` (`Record_ID`),
  ADD KEY `fk_Patient_Record_Patient1_idx` (`Patient_ID`),
  ADD KEY `fk_Patient_Record_Doctor1_idx` (`Doctor_ID`),
  ADD KEY `patient_diag` (`Diagnoses`);

--
-- Indexes for table `payment`
--
ALTER TABLE `payment`
  ADD PRIMARY KEY (`payment_ID`),
  ADD KEY `Bill_ID` (`Bill_ID`),
  ADD KEY `payment_type` (`Payment_Type`),
  ADD KEY `payment_status` (`Payment_Status`);

--
-- Indexes for table `radiology_test`
--
ALTER TABLE `radiology_test`
  ADD PRIMARY KEY (`Rad_ID`,`Patient_ID`),
  ADD UNIQUE KEY `Rad_ID_UNIQUE` (`Rad_ID`),
  ADD KEY `fk_Radiology_Test_Patient1_idx` (`Patient_ID`);

--
-- Indexes for table `room`
--
ALTER TABLE `room`
  ADD PRIMARY KEY (`Room_ID`,`Block_B_ID`),
  ADD UNIQUE KEY `Room_ID_UNIQUE` (`Room_ID`),
  ADD KEY `fk_Room_Building_Block1_idx` (`Block_B_ID`);

--
-- Indexes for table `salary_record`
--
ALTER TABLE `salary_record`
  ADD PRIMARY KEY (`salary_ID`,`Emp_ID`),
  ADD UNIQUE KEY `salary_ID_UNIQUE` (`salary_ID`),
  ADD KEY `fk_Salary_Record_Employee_Manager1_idx` (`Emp_ID`),
  ADD KEY `salary_idx` (`Salary`),
  ADD KEY `bonus_idx` (`Bonus`),
  ADD KEY `compesation_idx` (`Compesation`);

--
-- Indexes for table `supplier_company`
--
ALTER TABLE `supplier_company`
  ADD PRIMARY KEY (`Company_ID`),
  ADD UNIQUE KEY `Company_ID_UNIQUE` (`Company_ID`),
  ADD KEY `company_idx` (`Company_Name`),
  ADD KEY `supplier_email_idx` (`Email`);

--
-- Indexes for table `system_notifications`
--
ALTER TABLE `system_notifications`
  ADD PRIMARY KEY (`notification_ID`);

--
-- Indexes for table `system_users`
--
ALTER TABLE `system_users`
  ADD PRIMARY KEY (`User_ID`),
  ADD UNIQUE KEY `User_ID_UNIQUE` (`User_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `Appointment_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `building_block`
--
ALTER TABLE `building_block`
  MODIFY `B_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `Dept_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `Doctor_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `employees`
--
ALTER TABLE `employees`
  MODIFY `Employee_ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `employee_manager`
--
ALTER TABLE `employee_manager`
  MODIFY `Emp_ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `hospital_bills`
--
ALTER TABLE `hospital_bills`
  MODIFY `Bill_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `medical_lab`
--
ALTER TABLE `medical_lab`
  MODIFY `Lab_ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `medicine`
--
ALTER TABLE `medicine`
  MODIFY `Medicine_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `medicine_record`
--
ALTER TABLE `medicine_record`
  MODIFY `Med_Record_ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `patient_admission`
--
ALTER TABLE `patient_admission`
  MODIFY `Admission_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `patient_record`
--
ALTER TABLE `patient_record`
  MODIFY `Record_ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payment`
--
ALTER TABLE `payment`
  MODIFY `payment_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `radiology_test`
--
ALTER TABLE `radiology_test`
  MODIFY `Rad_ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `room`
--
ALTER TABLE `room`
  MODIFY `Room_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `salary_record`
--
ALTER TABLE `salary_record`
  MODIFY `salary_ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `supplier_company`
--
ALTER TABLE `supplier_company`
  MODIFY `Company_ID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_notifications`
--
ALTER TABLE `system_notifications`
  MODIFY `notification_ID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `system_users`
--
ALTER TABLE `system_users`
  MODIFY `User_ID` int NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `fk_Appointment_Doctor1` FOREIGN KEY (`Doctor_ID`) REFERENCES `doctor` (`Doctor_ID`) ON DELETE CASCADE ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_Appointment_Patient` FOREIGN KEY (`Patient_ID`) REFERENCES `patient` (`Patient_ID`) ON DELETE CASCADE ON UPDATE RESTRICT;

--
-- Constraints for table `employees`
--
ALTER TABLE `employees`
  ADD CONSTRAINT `fk_Employee_Department1` FOREIGN KEY (`Dept_ID`) REFERENCES `department` (`Dept_ID`);

--
-- Constraints for table `employee_manager`
--
ALTER TABLE `employee_manager`
  ADD CONSTRAINT `fk_Employee_Manager_Department1` FOREIGN KEY (`Dept_ID`) REFERENCES `department` (`Dept_ID`) ON DELETE CASCADE ON UPDATE RESTRICT;

--
-- Constraints for table `health_insurance`
--
ALTER TABLE `health_insurance`
  ADD CONSTRAINT `fk_Health_Insurance_Has_Insurance1` FOREIGN KEY (`Insurance_Code`) REFERENCES `has_insurance` (`Insurance_Code`) ON DELETE CASCADE ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_Health_Insurance_Patient1` FOREIGN KEY (`Patient_ID`) REFERENCES `patient` (`Patient_ID`) ON DELETE CASCADE ON UPDATE RESTRICT;

--
-- Constraints for table `hospital_bills`
--
ALTER TABLE `hospital_bills`
  ADD CONSTRAINT `fk_Hospital_Bills_Health_Insurance1` FOREIGN KEY (`Insurance_Number`) REFERENCES `health_insurance` (`Insurance_Number`),
  ADD CONSTRAINT `fk_Hospital_Bills_Patient1` FOREIGN KEY (`Patient_ID`) REFERENCES `patient` (`Patient_ID`);

--
-- Constraints for table `medical_lab`
--
ALTER TABLE `medical_lab`
  ADD CONSTRAINT `fk_Medical_Lab_Patient1` FOREIGN KEY (`Patient_ID`) REFERENCES `patient` (`Patient_ID`);

--
-- Constraints for table `medicine_prescription`
--
ALTER TABLE `medicine_prescription`
  ADD CONSTRAINT `fk_Medicine_Prescription_Medicine1` FOREIGN KEY (`Medicine_ID`) REFERENCES `medicine` (`Medicine_ID`) ON DELETE CASCADE ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_Medicine_Prescription_Patient_Record1` FOREIGN KEY (`Record_ID`) REFERENCES `patient_record` (`Record_ID`) ON DELETE CASCADE ON UPDATE RESTRICT;

--
-- Constraints for table `medicine_record`
--
ALTER TABLE `medicine_record`
  ADD CONSTRAINT `fk_Medicine_Record_Medicine1` FOREIGN KEY (`Medicine_ID`) REFERENCES `medicine` (`Medicine_ID`),
  ADD CONSTRAINT `fk_Medicine_Record_Supplier_Company1` FOREIGN KEY (`Company_ID`) REFERENCES `supplier_company` (`Company_ID`);

--
-- Constraints for table `patient_admission`
--
ALTER TABLE `patient_admission`
  ADD CONSTRAINT `fk_Patient_Admission_Patient1` FOREIGN KEY (`Patient_ID`) REFERENCES `patient` (`Patient_ID`) ON DELETE CASCADE ON UPDATE RESTRICT,
  ADD CONSTRAINT `fk_Patient_Admission_Room1` FOREIGN KEY (`Room_ID`) REFERENCES `room` (`Room_ID`) ON DELETE CASCADE ON UPDATE RESTRICT;

--
-- Constraints for table `patient_record`
--
ALTER TABLE `patient_record`
  ADD CONSTRAINT `fk_Patient_Record_Doctor1` FOREIGN KEY (`Doctor_ID`) REFERENCES `doctor` (`Doctor_ID`),
  ADD CONSTRAINT `fk_Patient_Record_Patient1` FOREIGN KEY (`Patient_ID`) REFERENCES `patient` (`Patient_ID`);

--
-- Constraints for table `payment`
--
ALTER TABLE `payment`
  ADD CONSTRAINT `payment_ibfk_1` FOREIGN KEY (`Bill_ID`) REFERENCES `hospital_bills` (`Bill_ID`) ON DELETE CASCADE ON UPDATE RESTRICT;

--
-- Constraints for table `radiology_test`
--
ALTER TABLE `radiology_test`
  ADD CONSTRAINT `fk_Radiology_Test_Patient1` FOREIGN KEY (`Patient_ID`) REFERENCES `patient` (`Patient_ID`);

--
-- Constraints for table `room`
--
ALTER TABLE `room`
  ADD CONSTRAINT `fk_Room_Building_Block1` FOREIGN KEY (`Block_B_ID`) REFERENCES `building_block` (`B_ID`);

--
-- Constraints for table `salary_record`
--
ALTER TABLE `salary_record`
  ADD CONSTRAINT `fk_Salary_Record_Employee_Manager1` FOREIGN KEY (`Emp_ID`) REFERENCES `employee_manager` (`Emp_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
